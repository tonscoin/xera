// ═══════════════════════════════════════════════════
//  globals.js — 전역 상태 & 공통 헬퍼 (v3 완전 수정판)
// ═══════════════════════════════════════════════════

const S = {
  members:    {},   // { member_no: {...} }
  sales:      [],   // [{ order_date, member_name, ddm_id, pv, amount, ... }]
  pvMap:      {},   // { member_no: pv }
  legPV:      {},   // { member_no: { L, R } }
  gradeMap:   {},
  honorMap:   {},   // { member_no: { grade, active } } — 인정자격 회원
  uMode:      { m:'server', s:'server' },
  loaded:     { members:false, sales:false, honor:false },
  periodMode: { ref:'week', match:'week', bin:'week', repurchase:'month' },
  binCarry:   {},   // { weekStr: { member_no: { L, R } } } — 바이너리 이월 PV 캐시
};

// ── 기본 헬퍼 ──
const $ = id => document.getElementById(id);
const fmt  = n => Number(n||0).toLocaleString('ko-KR');
const fmtW = n => '₩' + fmt(n);
const str  = v => (v===null||v===undefined) ? '' : String(v).trim();
const toI  = v => {
  try {
    const s = String(v||0).replace(/[,\t\s]/g,'');  // 콤마·탭·공백 제거
    // 소수점 포함(800000.00) → parseFloat 후 Math.round
    if (s.indexOf('.') !== -1) return Math.round(parseFloat(s)) || 0;
    return parseInt(s) || 0;
  } catch { return 0; }
};
const period = () => $('period') ? $('period').value : '';

// ── 등급 계산 (개인 PV 기준) ──
function calcGradeJs(pv) {
  if (pv >= 800000) return '플래티넘';
  if (pv >= 560000) return '골드';
  if (pv >= 320000) return '플러스';
  if (pv >= 100000) return '베이직';
  return '미달성';
}

// ── 등급: max_grade(누적) vs 월PV 등급 vs 인정등급 중 더 높은 것 ──
// 인정등급은 active 여부와 무관하게 항상 등급 계산에 반영
// (active=정지여도 인정등급은 유지, 단 수당 자격 부여만 안 됨)
function getEffectiveGrade(memberNo, monthPv) {
  const m = S.members[memberNo] || {};
  const maxGrade    = m.max_grade || m.grade || '';
  const pvGrade     = calcGradeJs(monthPv);
  const cachedGrade = S.gradeMap[memberNo] || '';
  const honorGrade  = S.honorMap[memberNo] ? (S.honorMap[memberNo].grade || '') : '';
  const order = { '미달성':0, '회원':0, '베이직':1, '플러스':2, '골드':3, '플래티넘':4 };
  const maxOrder = Math.max(order[maxGrade]||0, order[pvGrade]||0, order[cachedGrade]||0, order[honorGrade]||0);
  const grades = ['미달성','베이직','플러스','골드','플래티넘'];
  for (let i = grades.length-1; i >= 0; i--) {
    if ((order[grades[i]]||0) === maxOrder) return grades[i];
  }
  return pvGrade || '미달성';
}

// ── 직급 계산 (소실적 PV 기준, 월 소실적) ──
// 직급수당 판단: 1스타=200만, 2스타=500만, 3스타=1000만, 4스타=2000만, 5스타=5000만
const RANK_THRESHOLDS = {
  '5스타': 50000000,
  '4스타': 20000000,
  '3스타': 10000000,
  '2스타':  5000000,
  '1스타':  2000000,
};
function calcRankJs(legPV) {
  const lesser = Math.min(legPV.L||0, legPV.R||0);
  if (lesser >= 50000000) return '5스타';
  if (lesser >= 20000000) return '4스타';
  if (lesser >= 10000000) return '3스타';
  if (lesser >= 5000000)  return '2스타';
  if (lesser >= 2000000)  return '1스타';
  return '미달성';
}

// ── 등급별 바이너리 주간 CAP ──
const GRADE_WEEKLY_CAPS = {
  '플래티넘': 10000000,
  '골드':     3000000,
  '플러스':   1500000,
  '베이직':   500000,
  '미달성':   0,
};

// ── 직급수당 풀 비율 ──
const RANK_POOL = {
  '1스타': { rate: 0.03, minLeg:  2000000 },
  '2스타': { rate: 0.02, minLeg:  5000000 },
  '3스타': { rate: 0.02, minLeg: 10000000 },
  '4스타': { rate: 0.03, minLeg: 20000000 },
  '5스타': { rate: 0.02, minLeg: 50000000 },
};
const RANK_ORDER = ['1스타','2스타','3스타','4스타','5스타'];

// ── 추천매칭 깊이별 요율 ──
// 기준 재원 = childPV × 20%
// 이 재원을 가중치 비율로 배분 (가중치 합계 100% 기준)
// 1대: 재원×20% = PV×4%, 2~7대: 재원×10% = PV×2%, 8~12대: 재원×4% = PV×0.8%
const MATCH_DEPTH_MAX = { '베이직':3, '플러스':5, '골드':8, '플래티넘':12 };
function matchRate(depth) {
  if (depth === 1) return 0.04;    // PV × 20% × 20% = PV × 4%
  if (depth <= 7)  return 0.02;    // PV × 20% × 10% = PV × 2%
  return 0.008;                    // PV × 20% × 4%  = PV × 0.8%
}

// ── 날짜 유틸 ──
function getWeekNumber(d) {
  const date = new Date(d);
  date.setHours(0,0,0,0);
  date.setDate(date.getDate() + 3 - (date.getDay()+6)%7);
  const week1 = new Date(date.getFullYear(),0,4);
  return 1 + Math.round(((date-week1)/86400000 - 3 + (week1.getDay()+6)%7)/7);
}
function getWeekString(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  return `${d.getFullYear()}-W${String(getWeekNumber(d)).padStart(2,'0')}`;
}

// ── 이전 주 weekStr 반환 ──
function getPrevWeekStr(weekStr) {
  const [yr, wk] = weekStr.split('-W').map(Number);
  if (wk <= 1) {
    // 전년도 마지막 주
    const dec28 = new Date(yr - 1, 11, 28);
    return getWeekString(dec28.toISOString().slice(0, 10));
  }
  const jan4 = new Date(yr, 0, 4);
  const dow = (jan4.getDay() + 6) % 7;
  const firstMonday = new Date(jan4.getTime() - dow * 86400000);
  const prevStart = new Date(firstMonday.getTime() + (wk - 2) * 7 * 86400000);
  return `${yr}-W${String(wk - 1).padStart(2, '0')}`;
}

// ── 바이너리 이월 PV 계산 (누적이월형) ──
// 해당 주 마감 후 대레그 잔여PV를 반환
// carryPV = { member_no: { L: carryL, R: carryR } }
function calcBinCarryForWeek(weekStr) {
  // 캐시 확인
  if (S.binCarry[weekStr]) return S.binCarry[weekStr];

  const wSales = filterSalesByPeriod(S.sales, weekStr, 'week');
  const wPvMap = buildPvMap(wSales);
  const wTotalPV = Object.values(wPvMap).reduce((a, b) => a + b, 0);
  if (wTotalPV === 0) {
    S.binCarry[weekStr] = {};
    return {};
  }

  // 이전 주 이월 PV 가져오기
  const prevWeekStr = getPrevWeekStr(weekStr);
  const prevCarry   = calcBinCarryForWeek(prevWeekStr); // 재귀

  // 이번 주 레그 PV (이월 + 신규) — qualDate 적용 버전
  const wQual   = buildQualifiedForWeek(weekStr, S.sales);
  const wNewLeg = buildLegPVQual(wSales, wQual);

  // CAP은 비율 조정 전 기준이므로 ratio 먼저 계산
  const CAPS = GRADE_WEEKLY_CAPS;
  const binRows = [];
  Object.keys(wQual).forEach(no => {
    const carry = prevCarry[no] || { L: 0, R: 0 };
    const newLeg = wNewLeg[no]  || { L: 0, R: 0 };
    const totalL = carry.L + newLeg.L;
    const totalR = carry.R + newLeg.R;
    if (!totalL || !totalR) return;
    const grade = getEffectiveGrade(no, wPvMap[no] || 0);
    const cap   = CAPS[grade] || 0;
    const raw   = Math.round(Math.min(totalL, totalR) * 0.10);
    const amt   = Math.min(raw, cap);
    if (amt > 0) binRows.push({ no, amt, totalL, totalR, cap });
  });

  const binTotal = binRows.reduce((s, r) => s + r.amt, 0);
  const binLimit = Math.round(wTotalPV * 0.80);
  const ratio    = (binTotal > binLimit && binTotal > 0) ? binLimit / binTotal : 1.0;

  // 이월 PV 산출: 대레그에서 실제 사용된 소레그PV 차감
  const carry = {};
  binRows.forEach(br => {
    const small     = Math.min(br.totalL, br.totalR);
    const finalAmt  = Math.round(br.amt * ratio);
    // ratio 적용 시 실제 소진된 소레그 PV
    const usedSmall = (ratio < 1.0) ? Math.round(small * ratio) : small;
    // cap 적용 시 실제 소진 PV = cap / 0.10
    const usedPV    = Math.round(finalAmt / 0.10);
    const newL = br.totalL >= br.totalR
      ? br.totalL - usedPV   // L이 대레그 → 잔여
      : 0;
    const newR = br.totalR >  br.totalL
      ? br.totalR - usedPV   // R이 대레그 → 잔여
      : 0;
    carry[br.no] = { L: Math.max(0, newL), R: Math.max(0, newR) };
  });

  // 수당 발생 없었던 자격회원: 전체 레그PV 이월
  Object.keys(wQual).forEach(no => {
    if (carry[no]) return;
    const prevC  = prevCarry[no] || { L: 0, R: 0 };
    const newLeg = wNewLeg[no]   || { L: 0, R: 0 };
    carry[no] = { L: prevC.L + newLeg.L, R: prevC.R + newLeg.R };
  });

  S.binCarry[weekStr] = carry;
  return carry;
}

// ── 수당 자격 판단 ──
// 직전달 OR 당월 10만PV 이상이면 해당 월 자격
function buildQualified(periodStr, allSales) {
  const [y, m] = periodStr.split('-').map(Number);
  const pm = m === 1 ? 12 : m - 1;
  const py = m === 1 ? y - 1 : y;
  const prevPeriod = `${py}-${String(pm).padStart(2,'0')}`;

  const prevPv = {}, currPv = {};
  allSales.forEach(s => {
    const no = findMemberNo(s);
    if (!no) return;
    const od = s.order_date || '';
    if (od.startsWith(prevPeriod)) prevPv[no] = (prevPv[no]||0) + (parseInt(s.pv)||0);
    if (od.startsWith(periodStr))  currPv[no] = (currPv[no]||0) + (parseInt(s.pv)||0);
  });

  const qualified = {};
  Object.keys(prevPv).forEach(no => { if (prevPv[no] >= 100000) qualified[no] = 'prev'; });
  Object.keys(currPv).forEach(no => { if (currPv[no] >= 100000 && !qualified[no]) qualified[no] = 'curr'; });

  // ── 수정#4/#6: 해당 기간 전체 PV=0 이면 인정자격도 부여 안 함
  // 매출이 없는 기간(3월 등)에 수당이 생기는 문제 완전 차단
  const periodTotalPV = allSales
    .filter(s => (s.order_date||'').startsWith(periodStr))
    .reduce((a, s) => a + (parseInt(s.pv)||0), 0);
  if (periodTotalPV === 0) return qualified;

  // ── 인정자격 회원: active=true + 기간 유효한 경우에만 자격 부여
  const periodDate = new Date(periodStr + '-01');
  Object.entries(S.honorMap).forEach(([no, h]) => {
    if (!h.active) return;
    // 인정등급 만료 체크
    if (h.grade_expire_date && new Date(h.grade_expire_date) < periodDate) return;
    // 인정자격(수당) 만료 체크
    if (h.qual_expire_date && new Date(h.qual_expire_date) < periodDate) return;
    if (!qualified[no]) qualified[no] = 'honor';
  });

  return qualified;
}

// 주기간 자격 판단 - 해당 주에 속한 모든 날짜의 달을 커버
function buildQualifiedForWeek(weekStr, allSales) {
  const [year, week] = weekStr.split('-W').map(Number);
  const jan4 = new Date(year, 0, 4);
  const dayOfWeek = (jan4.getDay() + 6) % 7;
  const firstMonday = new Date(jan4.getTime() - dayOfWeek * 86400000);
  const weekStart = new Date(firstMonday.getTime() + (week - 1) * 7 * 86400000);
  const weekEnd   = new Date(weekStart.getTime() + 6 * 86400000);

  // 주의 시작/끝 달이 다를 수 있으므로 양쪽 모두 자격 판단
  const months = new Set();
  for (let d = new Date(weekStart); d <= weekEnd; d.setDate(d.getDate() + 1)) {
    months.add(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`);
  }
  const qualified = {};
  months.forEach(mo => {
    const q = buildQualified(mo, allSales);
    Object.keys(q).forEach(no => { if (!qualified[no]) qualified[no] = q[no]; });
  });

  // ── 누적 PV 10만 달성일 계산 ──
  // 날짜순 누적하여 처음 10만 이상 된 날 = 자격취득일
  const memberSales = {};
  allSales.forEach(s => {
    const no = findMemberNo(s);
    if (!no) return;
    const od = s.order_date || '';
    if (!od) return;
    if (!memberSales[no]) memberSales[no] = [];
    memberSales[no].push({ date: od, pv: parseInt(s.pv) || 0 });
  });

  const qualAcquiredDate = {}; // { member_no: 'YYYY-MM-DD' }
  Object.entries(memberSales).forEach(([no, orders]) => {
    orders.sort((a, b) => a.date < b.date ? -1 : 1);
    let cum = 0;
    for (const o of orders) {
      cum += o.pv;
      if (cum >= 100000) {
        qualAcquiredDate[no] = o.date;
        break;
      }
    }
  });

  // ── 자격 필터링 ──
  // honor 회원: 항상 자격 (취득일 = 아주 옛날로 설정)
  // 일반 회원: 자격취득일이 있어야 하며, 반환값에 취득일 포함
  const result = {}; // { member_no: { type, qualDate } }
  // 주 시작일 (YYYY-MM-DD)
  const weekStartStr = weekStart.getFullYear() + '-'
    + String(weekStart.getMonth()+1).padStart(2,'0') + '-'
    + String(weekStart.getDate()).padStart(2,'0');

  Object.keys(qualified).forEach(no => {
    if (qualified[no] === 'honor') {
      // 인정자격 회원: honor_acquired_date(관리자가 설정한 자격취득일) 우선 사용
      // 없으면 주 시작일 사용 (= 해당 주 처음부터 수당 자격 부여)
      const honorInfo = S.honorMap[no] || {};
      const honorAcquired = (honorInfo.honor_acquired_date || '').substring(0, 10);
      // honor_acquired_date가 설정된 경우: 해당 날짜 이후 구매부터 수당
      // 미설정: 주 시작일부터 (해당 주 전체 매출에 수당 적용)
      const honorDate = honorAcquired || weekStartStr;
      result[no] = { type: 'honor', qualDate: honorDate };
      return;
    }
    const qd = qualAcquiredDate[no];
    if (!qd) return; // 10만 미달성 → 자격 없음
    result[no] = { type: qualified[no], qualDate: qd };
  });

  return result;
}

// ── 회원번호 탐색 ──
function findMemberNo(s) {
  if (!s) return null;
  if (s.ddm_id) {
    for (const m of Object.values(S.members)) {
      if (m.login_id === s.ddm_id) return m.member_no;
    }
  }
  if (s.member_name) {
    for (const m of Object.values(S.members)) {
      if (m.name === s.member_name) return m.member_no;
    }
  }
  return null;
}

// ── API 패치 ──
async function apiFetch(url) {
  try {
    const r = await fetch(url, { headers:{'X-Requested-With':'XMLHttpRequest'} });
    if (!r.ok) return {};
    return await r.json();
  } catch(e) { console.error('apiFetch error:', url, e); return {}; }
}

// ── 데이터 로더 ──
async function ensureData(periodStr) {
  if (!S.loaded.members || !Object.keys(S.members).length) {
    const d = await apiFetch('api/data.php?action=members');
    (d.data||[]).forEach(m => { S.members[m.member_no] = m; });
    S.loaded.members = true;
  }
  const year = (periodStr||'').substring(0,4) || String(new Date().getFullYear());
  if (!S.loaded.sales || !S.sales.length || (S._salesYear && S._salesYear !== year)) {
    const sd = await apiFetch(`api/data.php?action=sales&period=${year}`);
    S.sales = sd.data || [];
    S.binCarry = {}; // 바이너리 이월 캐시 초기화
    S.loaded.sales = true;
    S._salesYear = year;
  }
  // 인정자격 회원 로드 (1회)
  if (!S.loaded.honor) {
    const hd = await apiFetch('api/honor.php?action=list');
    S.honorMap = {};
    (hd.data||[]).forEach(h => { S.honorMap[h.member_no] = h; });
    S.loaded.honor = true;
  }
}

// ── legPV 빌더 (qualDate 미적용 — 직급/팝업 표시용) ──
function buildLegPV(pvMap) {
  const legPV = {};
  Object.values(S.members).forEach(mb => {
    const pv = pvMap[mb.member_no] || 0;
    if (!pv) return;
    let cur = mb.sponsor_no, pos = mb.position || 'L';
    while (cur && S.members[cur]) {
      if (!legPV[cur]) legPV[cur] = { L:0, R:0 };
      legPV[cur][pos] = (legPV[cur][pos]||0) + pv;
      pos = S.members[cur].position || 'L';
      cur = S.members[cur].sponsor_no;
    }
  });
  return legPV;
}

// ── legPV 빌더 (qualDate 적용 — 바이너리 수당 계산 전용) ──
// sales: 해당 기간 매출 배열, qual: { member_no: { type, qualDate } }
// 상위 회원의 자격취득일(qualDate) 이후 매출만 레그에 반영
function buildLegPVQual(sales, qual) {
  const legPV = {};
  sales.forEach(s => {
    const buyNo = findMemberNo(s);
    if (!buyNo) return;
    const pv = parseInt(s.pv) || 0;
    if (!pv) return;
    const saleDate = s.order_date || '';
    // 후원 라인을 따라 상위 회원에 레그 누적
    let cur = S.members[buyNo]?.sponsor_no;
    let pos = S.members[buyNo]?.position || 'L';
    while (cur && S.members[cur]) {
      // 자격자이고, 매출일 >= 상위 회원의 자격취득일인 경우만 반영
      if (qual[cur]) {
        const qualDate = qual[cur].qualDate || '';
        if (!qualDate || saleDate >= qualDate) {
          if (!legPV[cur]) legPV[cur] = { L:0, R:0 };
          legPV[cur][pos] = (legPV[cur][pos]||0) + pv;
        }
      }
      pos = S.members[cur].position || 'L';
      cur = S.members[cur].sponsor_no;
    }
  });
  return legPV;
}

// ── refCh 빌더 ──
function buildRefCh() {
  const refCh = {};
  Object.values(S.members).forEach(mb => {
    if (mb.referrer_no) {
      if (!refCh[mb.referrer_no]) refCh[mb.referrer_no] = [];
      refCh[mb.referrer_no].push(mb.member_no);
    }
  });
  return refCh;
}

// ── PV 집계 ──
function buildPvMap(sales) {
  const pvMap = {};
  sales.forEach(s => {
    const no = findMemberNo(s);
    if (no) pvMap[no] = (pvMap[no]||0) + (parseInt(s.pv)||0);
  });
  return pvMap;
}

// ── 기간 필터 ──
function filterSalesByPeriod(sales, periodVal, mode) {
  if (mode === 'week') {
    const [year, week] = periodVal.split('-W').map(Number);
    return sales.filter(s => {
      if (!s.order_date) return false;
      const d = new Date(s.order_date);
      return d.getFullYear() == year && getWeekNumber(d) == week;
    });
  }
  return sales.filter(s => (s.order_date||'').startsWith(periodVal));
}

// ── 추천 깊이 탐색 ──
function traverseDepthJs(refCh, rootNo, maxDepth) {
  const found = {};
  const queue = [{no: rootNo, depth: 0}];
  while (queue.length) {
    const {no, depth} = queue.shift();
    if (depth > 0) {
      if (!found[depth]) found[depth] = [];
      found[depth].push(no);
    }
    if (depth < maxDepth) {
      (refCh[no]||[]).forEach(c => queue.push({no:c, depth:depth+1}));
    }
  }
  return found;
}

// ── 핵심 수당 계산 (프론트엔드 로컬) ──
// ── 해당 월의 주 목록 반환 (YYYY-Www 형식) ──
function getWeeksInMonth(periodStr) {
  const [y, mo] = periodStr.split('-').map(Number);
  const weeks = new Set();
  const daysInMonth = new Date(y, mo, 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(y, mo - 1, d);
    weeks.add(`${date.getFullYear()}-W${String(getWeekNumber(date)).padStart(2,'0')}`);
  }
  return [...weeks];
}

function calcAllComm(periodStr) {
  const m = S.members;
  const filtered = S.sales.filter(s => (s.order_date||'').startsWith(periodStr));

  // ── 수정#4/#6: 해당 기간 매출 PV=0 이면 수당 계산 안 함
  const _chkPV = filtered.reduce((a,s)=>a+(parseInt(s.pv)||0),0);
  if (_chkPV === 0) return { data:[], total_payout:0, period:periodStr, total_pv:0, total_sales:0,
    pvMap:{}, legPV:{}, qual:{}, rankMems:{}, lottoPool:0, lottoScores:{}, binRatio:1 };

  // 월 전체 PV맵 (직급수당·로또·직추재구매 기준)
  const pvMap   = buildPvMap(filtered);
  const refCh   = buildRefCh();
  const qual    = buildQualified(periodStr, S.sales);
  const totalPV = Object.values(pvMap).reduce((a,b)=>a+b,0);
  // 모든 레그PV 계산에 qualDate 적용 — 각 주차 qual을 합산해 월 전체 qualMap 구성
  const _allWQual = {};
  getWeeksInMonth(periodStr).forEach(wk => {
    const wq = buildQualifiedForWeek(wk, S.sales);
    Object.entries(wq).forEach(([no, v]) => {
      if (!_allWQual[no] || v.qualDate < _allWQual[no].qualDate) _allWQual[no] = v;
    });
  });
  const legPV     = buildLegPV(pvMap);          // 하위호환용 (반환값 포함)
  const legPVQual = buildLegPVQual(filtered, _allWQual); // 수당 계산 전용

  const commMap = {};
  const addC = (no, type, amt) => {
    if (amt <= 0) return;
    const truncated = Math.floor(amt / 10) * 10;  // 원단위 절삭 (10원 미만 버림)
    if (truncated <= 0) return;
    if (!commMap[no]) commMap[no] = { name:m[no]?.name||no, items:{} };
    commMap[no].items[type] = (commMap[no].items[type]||0) + truncated;
  };

  // ── 주지급 수당: 주별로 분리하여 CAP 적용 ──
  const weeks = getWeeksInMonth(periodStr);
  let totalBinRatio = 1.0; // 마지막 주 기준 프로라타 (참고용)

  weeks.forEach(weekStr => {
    const wSales = filterSalesByPeriod(S.sales, weekStr, 'week');
    const wPvMap = buildPvMap(wSales);
    const wQual  = buildQualifiedForWeek(weekStr, S.sales);
    const wLegPV = buildLegPVQual(wSales, wQual);
    const wTotalPV = Object.values(wPvMap).reduce((a,b)=>a+b,0);

    // 01 추천수당 10% (주지급)
    // 구매일 >= 추천인의 자격취득일 인 경우에만 수당 발생
    wSales.forEach(s => {
      const buyNo = findMemberNo(s);
      if (!buyNo) return;
      const refNo = m[buyNo]?.referrer_no;
      if (!refNo || !wQual[refNo]) return;
      // 자격취득일 이후 구매건만 수당 발생
      const saleDate = s.order_date || '';
      if (saleDate < wQual[refNo].qualDate) return;
      addC(refNo, '추천수당', Math.round((parseInt(s.pv)||0) * 0.10));
    });

    // 02 추천매칭수당 (주지급) - 건별 계산으로 반올림 오차 방지
    Object.keys(wQual).forEach(no => {
      const grade    = getEffectiveGrade(no, wPvMap[no] || 0);
      const maxDepth = MATCH_DEPTH_MAX[grade] || 3;
      const found    = traverseDepthJs(refCh, no, maxDepth);
      Object.entries(found).forEach(([depth, list]) => {
        const d    = parseInt(depth);
        const rate = matchRate(d);
        list.forEach(childNo => {
          // 건별로 각각 계산 후 합산 + 자격취득일 이후 구매건만
          wSales.filter(s => findMemberNo(s) === childNo).forEach(s => {
            const spv = parseInt(s.pv) || 0;
            if (!spv) return;
            const saleDate = s.order_date || '';
            if (saleDate < wQual[no].qualDate) return; // 자격취득 전 구매 제외
            addC(no, `추천매칭수당_${d}대`, Math.round(spv * rate));
          });
        });
      });
    });

    // 03 바이너리수당 10% (주지급, 주간 CAP 적용)
    // wQual이 이제 { no: { type, qualDate } } 구조
    if (wTotalPV > 0) {
      const wBinRows = [];
      Object.keys(wQual).forEach(no => {
        const l = wLegPV[no]?.L||0, r = wLegPV[no]?.R||0;
        if (!l || !r) return;
        const grade = getEffectiveGrade(no, wPvMap[no]||0);
        const cap   = GRADE_WEEKLY_CAPS[grade] || 0;
        const amt   = Math.min(Math.round(Math.min(l,r)*0.10), cap);
        if (amt > 0) wBinRows.push({ no, amt });
      });
      const wBinTotal = wBinRows.reduce((s,r)=>s+r.amt,0);
      const wBinLimit = Math.round(wTotalPV * 0.80);
      const wBinRatio = (wBinTotal > wBinLimit && wBinTotal > 0) ? wBinLimit / wBinTotal : 1.0;
      totalBinRatio = wBinRatio;
      wBinRows.forEach(br => addC(br.no, '바이너리수당', Math.round(br.amt * wBinRatio)));
    }
  });

  // ── 월지급 수당 ──

  // 04 직급수당 (월 소실적 기준, 중복공유) — qualDate 적용 legPV 사용
  const rankMems = {};
  Object.keys(qual).forEach(no => {
    const lp   = legPVQual[no] || {L:0,R:0};
    const rank = calcRankJs(lp);
    if (rank !== '미달성') {
      if (!rankMems[rank]) rankMems[rank] = [];
      rankMems[rank].push(no);
    }
  });
  RANK_ORDER.forEach(rank => {
    const pool = RANK_POOL[rank];
    if (!pool) return;
    const poolAmt = Math.round(totalPV * pool.rate);
    const receivers = {};
    RANK_ORDER.slice(RANK_ORDER.indexOf(rank)).forEach(r2 => {
      (rankMems[r2]||[]).forEach(no => { receivers[no] = true; });
    });
    const rcvArr = Object.keys(receivers);
    if (rcvArr.length > 0 && poolAmt > 0) {
      const per = Math.round(poolAmt / rcvArr.length);
      rcvArr.forEach(no => addC(no, `직급수당_${rank}`, per));
    }
  });

  // 05 로또보너스 (월지급, 99만원 이상 신규+재구매, 5건 단위 점수제)
  const lottoPool = Math.round(totalPV * 0.03);
  const lottoRefCount = {};
  filtered.forEach(s => {
    const buyNo = findMemberNo(s);
    if (!buyNo) return;
    const refNo = m[buyNo]?.referrer_no;
    if (!refNo) return;
    if ((parseInt(s.amount)||0) >= 990000) {
      lottoRefCount[refNo] = (lottoRefCount[refNo]||0) + 1;
    }
  });
  const lottoScores = {};
  let totalLottoScore = 0;
  Object.entries(lottoRefCount).forEach(([no, cnt]) => {
    if (cnt < 5 || !qual[no]) return;
    const score = Math.floor(cnt / 5);
    lottoScores[no] = score;
    totalLottoScore += score;
  });
  if (totalLottoScore > 0 && lottoPool > 0) {
    Object.entries(lottoScores).forEach(([no, score]) => {
      addC(no, '로또보너스', Math.round(lottoPool * score / totalLottoScore));
    });
  }

  // 06 직추재구매수당 3% (월지급)
  Object.keys(qual).forEach(no => {
    const repurchSales = filtered.filter(s => {
      const buyNo = findMemberNo(s);
      return buyNo && m[buyNo]?.referrer_no === no && isRepurchase(s);
    });
    const activeDirRefs = [...new Set(repurchSales.map(s => findMemberNo(s)).filter(Boolean))];
    if (activeDirRefs.length < 3) return;
    const tv  = activeDirRefs.reduce((a, c) => a + (pvMap[c] || 0), 0);
    const amt = Math.round(tv * 0.03);
    if (amt > 0) addC(no, '직추재구매수당', amt);
  });

  // 결과 정리
  const result = {};
  Object.entries(commMap).forEach(([no, d]) => {
    const grade    = getEffectiveGrade(no, pvMap[no]||0);
    const items    = d.items;
    const refAmt   = items['추천수당'] || 0;
    const matchAmt = Object.entries(items).filter(([k])=>k.startsWith('추천매칭수당')).reduce((s,[,v])=>s+v,0);
    const binAmt   = items['바이너리수당'] || 0;
    const rankAmt  = Object.entries(items).filter(([k])=>k.startsWith('직급수당')).reduce((s,[,v])=>s+v,0);
    const repurAmt = items['직추재구매수당'] || 0;
    const lottoAmt = items['로또보너스'] || 0;
    const total    = refAmt + matchAmt + binAmt + rankAmt + repurAmt + lottoAmt;
    if (total <= 0) return;
    result[no] = {
      member_no: no,
      name: d.name,
      grade,
      pv: pvMap[no] || 0,
      ref: refAmt,
      match: matchAmt,
      bin: binAmt,
      rank: rankAmt,
      repurch: repurAmt,
      lotto: lottoAmt,
      total,
    };
  });

  const totalSales = filtered.reduce((s, r) => s + (parseInt(r.amount)||0), 0);
  const rows = Object.values(result).sort((a,b)=>b.total-a.total);
  return {
    data: rows,
    total_payout: rows.reduce((s,r)=>s+r.total,0),
    period: periodStr,
    total_pv: totalPV,
    total_sales: totalSales,
    pvMap, legPV, legPVQual, qual, rankMems,
    lottoPool, lottoScores,
    binRatio: totalBinRatio,
  };
}

// ── 주 단위 단일 통합 수당 계산 (통합 패널 주단위 모드용) ──
function calcAllCommWeek(weekStr) {
  const m = S.members;
  const wSales  = filterSalesByPeriod(S.sales, weekStr, 'week');

  // ── 수정#4: 해당 주 매출 PV=0 이면 수당 계산 안 함
  const _wChkPV = wSales.reduce((a,s)=>a+(parseInt(s.pv)||0),0);
  if (_wChkPV === 0) return { data:[], total_payout:0, period:weekStr, total_pv:0, total_sales:0,
    pvMap:{}, legPV:{}, qual:{}, rankMems:{}, lottoPool:0, lottoScores:{}, binRatio:1 };

  const wPvMap  = buildPvMap(wSales);
  const refCh   = buildRefCh();
  const wQual   = buildQualifiedForWeek(weekStr, S.sales);
  const wLegPV  = buildLegPVQual(wSales, wQual);
  const wTotalPV = Object.values(wPvMap).reduce((a,b)=>a+b,0);

  // 해당 주의 월 (직급·로또·직추재구매 기준)
  const [yr, wk] = weekStr.split('-W').map(Number);
  const jan4 = new Date(yr, 0, 4);
  const firstMonday = new Date(jan4.getTime() - ((jan4.getDay()+6)%7)*86400000);
  const weekStart = new Date(firstMonday.getTime() + (wk-1)*7*86400000);
  const monthStr = `${weekStart.getFullYear()}-${String(weekStart.getMonth()+1).padStart(2,'0')}`;
  const mFiltered = S.sales.filter(s => (s.order_date||'').startsWith(monthStr));
  const mPvMap = buildPvMap(mFiltered);
  const mQual  = buildQualified(monthStr, S.sales);
  // 직급 소실적도 qualDate 적용
  const _mWQual = {};
  getWeeksInMonth(monthStr).forEach(wk => {
    const wq = buildQualifiedForWeek(wk, S.sales);
    Object.entries(wq).forEach(([no, v]) => {
      if (!_mWQual[no] || v.qualDate < _mWQual[no].qualDate) _mWQual[no] = v;
    });
  });
  const mLegPV = buildLegPVQual(mFiltered, _mWQual);
  const mTotalPV = Object.values(mPvMap).reduce((a,b)=>a+b,0);

  const commMap = {};
  // detailLog: { [memberNo]: { ref:[], match:[], bin:[] } }
  const detailLog = {};

  const addC = (no, type, amt, detail) => {
    if (amt <= 0) return;
    const truncated = Math.floor(amt / 10) * 10;
    if (truncated <= 0) return;
    if (!commMap[no]) commMap[no] = { name:m[no]?.name||no, items:{} };
    commMap[no].items[type] = (commMap[no].items[type]||0) + truncated;
    // 상세 로그 저장
    if (detail) {
      if (!detailLog[no]) detailLog[no] = { ref:[], match:[], bin:[] };
      const cat = detail.cat || 'ref';
      detailLog[no][cat].push({ ...detail, amt: truncated });
    }
  };

  // 01 추천수당 10% (주지급 - 해당 주 구매분)
  wSales.forEach(s => {
    const buyNo = findMemberNo(s);
    if (!buyNo) return;
    const refNo = m[buyNo]?.referrer_no;
    if (!refNo || !wQual[refNo]) return;
    const saleDate = s.order_date || '';
    if (saleDate < wQual[refNo].qualDate) return;
    const pv  = parseInt(s.pv) || 0;
    const amt = Math.round(pv * 0.10);
    addC(refNo, '추천수당', amt, {
      cat: 'ref',
      date: saleDate,
      buyerNo: buyNo,
      buyerName: m[buyNo]?.name || buyNo,
      pv,
      rate: 10,
    });
  });

  // 02 추천매칭수당 (주지급)
  Object.keys(wQual).forEach(no => {
    const grade    = getEffectiveGrade(no, wPvMap[no] || 0);
    const maxDepth = MATCH_DEPTH_MAX[grade] || 3;
    const found    = traverseDepthJs(refCh, no, maxDepth);
    Object.entries(found).forEach(([depth, list]) => {
      const d    = parseInt(depth);
      const rate = matchRate(d);
      list.forEach(childNo => {
        wSales.filter(s => findMemberNo(s) === childNo).forEach(s => {
          const spv = parseInt(s.pv) || 0;
          if (!spv) return;
          const saleDate = s.order_date || '';
          if (saleDate < wQual[no].qualDate) return;
          const amt = Math.round(spv * rate);
          addC(no, `추천매칭수당_${d}대`, amt, {
            cat: 'match',
            date: saleDate,
            buyerNo: childNo,
            buyerName: m[childNo]?.name || childNo,
            depth: d,
            pv: spv,
            rate: Math.round(rate * 100),
          });
        });
      });
    });
  });

  // 03 바이너리수당 10% (주지급, 주간 CAP) ── 누적이월형 ──
  // 이전 주 대레그 잔여PV 이월 + 이번 주 신규 레그PV 합산
  const prevWeekStr = getPrevWeekStr(weekStr);
  const prevCarry   = calcBinCarryForWeek(prevWeekStr);

  const wBinRows = [];
  Object.keys(wQual).forEach(no => {
    const carry  = prevCarry[no] || { L: 0, R: 0 };
    const newLeg = wLegPV[no]    || { L: 0, R: 0 };
    const totalL = carry.L + newLeg.L;
    const totalR = carry.R + newLeg.R;
    if (!totalL || !totalR) return;
    const grade = getEffectiveGrade(no, wPvMap[no]||0);
    const cap   = GRADE_WEEKLY_CAPS[grade] || 0;
    const small = Math.min(totalL, totalR);
    const amt   = Math.min(Math.round(small * 0.10), cap);
    if (amt > 0) wBinRows.push({ no, amt, l: totalL, r: totalR, cap,
                                  carryL: carry.L, carryR: carry.R });
  });
  const wBinTotal = wBinRows.reduce((s,r)=>s+r.amt,0);
  const wBinLimit = Math.round(wTotalPV * 0.80);
  const binRatio  = (wBinTotal > wBinLimit && wBinTotal > 0) ? wBinLimit / wBinTotal : 1.0;

  // 이번 주 이월 PV 캐시 저장 (다음 주 계산에서 사용)
  const thisWeekCarry = {};
  wBinRows.forEach(br => {
    const finalAmt = Math.round(br.amt * binRatio);
    const usedPV   = Math.round(finalAmt / 0.10);
    const cL = br.l >= br.r ? Math.max(0, br.l - usedPV) : 0;
    const cR = br.r >  br.l ? Math.max(0, br.r - usedPV) : 0;
    thisWeekCarry[br.no] = { L: cL, R: cR };
  });
  // 수당 미발생 자격회원도 전체 이월
  Object.keys(wQual).forEach(no => {
    if (thisWeekCarry[no]) return;
    const carry  = prevCarry[no] || { L: 0, R: 0 };
    const newLeg = wLegPV[no]    || { L: 0, R: 0 };
    thisWeekCarry[no] = { L: carry.L + newLeg.L, R: carry.R + newLeg.R };
  });
  S.binCarry[weekStr] = thisWeekCarry;

  wBinRows.forEach(br => {
    const finalAmt = Math.round(br.amt * binRatio);
    addC(br.no, '바이너리수당', finalAmt, {
      cat: 'bin',
      legL: br.l,
      legR: br.r,
      small: Math.min(br.l, br.r),
      cap: br.cap,
      ratio: Math.round(binRatio * 10000) / 10000,
      pv: Math.min(br.l, br.r),
      rate: 10,
      carryL: br.carryL,
      carryR: br.carryR,
    });
  });

  // 04 직급수당 (월지급 - 해당 주 포함 월 기준)
  const rankMems = {};
  Object.keys(mQual).forEach(no => {
    const lp   = mLegPV[no] || {L:0,R:0};
    const rank = calcRankJs(lp);
    if (rank !== '미달성') {
      if (!rankMems[rank]) rankMems[rank] = [];
      rankMems[rank].push(no);
    }
  });
  RANK_ORDER.forEach(rank => {
    const pool = RANK_POOL[rank];
    if (!pool) return;
    const poolAmt = Math.round(mTotalPV * pool.rate);
    const receivers = {};
    RANK_ORDER.slice(RANK_ORDER.indexOf(rank)).forEach(r2 => {
      (rankMems[r2]||[]).forEach(no => { receivers[no] = true; });
    });
    const rcvArr = Object.keys(receivers);
    if (rcvArr.length > 0 && poolAmt > 0) {
      const per = Math.round(poolAmt / rcvArr.length);
      rcvArr.forEach(no => addC(no, `직급수당_${rank}`, per));
    }
  });

  // 05 로또보너스 (월지급)
  const lottoPool = Math.round(mTotalPV * 0.03);
  const lottoRefCount = {};
  mFiltered.forEach(s => {
    const buyNo = findMemberNo(s);
    if (!buyNo) return;
    const refNo = m[buyNo]?.referrer_no;
    if (!refNo) return;
    if ((parseInt(s.amount)||0) >= 990000) lottoRefCount[refNo] = (lottoRefCount[refNo]||0) + 1;
  });
  const lottoScores = {};
  let totalLottoScore = 0;
  Object.entries(lottoRefCount).forEach(([no, cnt]) => {
    if (cnt < 5 || !mQual[no]) return;
    const score = Math.floor(cnt / 5);
    lottoScores[no] = score;
    totalLottoScore += score;
  });
  if (totalLottoScore > 0 && lottoPool > 0) {
    Object.entries(lottoScores).forEach(([no, score]) => {
      addC(no, '로또보너스', Math.round(lottoPool * score / totalLottoScore));
    });
  }

  // 06 직추재구매수당 (월지급)
  Object.keys(mQual).forEach(no => {
    const repurchSales = mFiltered.filter(s => {
      const buyNo = findMemberNo(s);
      return buyNo && m[buyNo]?.referrer_no === no && isRepurchase(s);
    });
    const activeDirRefs = [...new Set(repurchSales.map(s => findMemberNo(s)).filter(Boolean))];
    if (activeDirRefs.length < 3) return;
    const tv  = activeDirRefs.reduce((a, c) => a + (mPvMap[c] || 0), 0);
    const amt = Math.round(tv * 0.03);
    if (amt > 0) addC(no, '직추재구매수당', amt);
  });

  // 결과 정리
  const result = {};
  Object.entries(commMap).forEach(([no, d]) => {
    const grade    = getEffectiveGrade(no, wPvMap[no]||0);
    const items    = d.items;
    const refAmt   = items['추천수당'] || 0;
    const matchAmt = Object.entries(items).filter(([k])=>k.startsWith('추천매칭수당')).reduce((s,[,v])=>s+v,0);
    const binAmt   = items['바이너리수당'] || 0;
    const rankAmt  = Object.entries(items).filter(([k])=>k.startsWith('직급수당')).reduce((s,[,v])=>s+v,0);
    const repurAmt = items['직추재구매수당'] || 0;
    const lottoAmt = items['로또보너스'] || 0;
    const total    = refAmt + matchAmt + binAmt + rankAmt + repurAmt + lottoAmt;
    if (total <= 0) return;
    result[no] = { member_no:no, name:d.name, grade, pv:wPvMap[no]||0,
      ref:refAmt, match:matchAmt, bin:binAmt, rank:rankAmt, repurch:repurAmt, lotto:lottoAmt, total,
      detail: detailLog[no] || { ref:[], match:[], bin:[] },
    };
  });

  const totalSales = wSales.reduce((s, r) => s + (parseInt(r.amount)||0), 0);
  const rows = Object.values(result).sort((a,b)=>b.total-a.total);
  return {
    data: rows,
    total_payout: rows.reduce((s,r)=>s+r.total,0),
    period: weekStr,
    total_pv: wTotalPV,
    total_sales: totalSales,
    pvMap: wPvMap, legPV: wLegPV, legPVQual: wLegPV,
    qual: wQual, rankMems, lottoPool, lottoScores, binRatio,
  };
}

// ── KPI 공통 렌더 ──
function showKpi(kpiId, html) {
  const el = $(kpiId);
  if (!el) return;
  el.innerHTML = html;
  el.style.display = 'grid';
}

// ── 주/월 토글 ──
function togglePeriod(btn, type, mode) {
  S.periodMode[type] = mode;
  btn.closest('.comm-period-bar').querySelectorAll('.btn.bo').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  $(`${type}-week`)  && ($(`${type}-week`).style.display  = mode==='week'  ? '' : 'none');
  $(`${type}-month`) && ($(`${type}-month`).style.display = mode==='month' ? '' : 'none');
}

// ── 업로드/파싱 유틸 ──
function normalizeGradeJs(raw) {
  const map = {
    '플래티넘':'플래티넘','골드':'골드','플러스':'플러스','베이직':'베이직',
    'PLATINUM':'플래티넘','GOLD':'골드','PLUS':'플러스','BASIC':'베이직',
  };
  return map[String(raw||'').trim()] || '미달성';
}

function toMember(r) {
  const csvGrade = normalizeGradeJs(r['등급'] || r['grade'] || '');
  return {
    member_no:      str(r['회원번호']),
    name:           str(r['이름']),
    login_id:       str(r['ID']),
    grade:          csvGrade,
    max_grade:      csvGrade,
    referrer_no:    str(r['추천인번호']),
    referrer_name:  str(r['추천인명']),
    sponsor_no:     str(r['후원인번호']),
    sponsor_name:   str(r['후원인명']),
    position:       str(r['위치']),
    phone:          str(r['휴대폰']),
    join_date:      str(r['가입일']).substring(0,10),
    center:         str(r['센터']),
    account_no:     str(r['계좌번호']),
    bank_name:      str(r['은행명']),
    account_holder: str(r['예금주']),
  };
}

function toSale(r) {
  const d = r['주문일'];
  let od = '';
  if (d instanceof Date) {
    od = d.toISOString().substring(0,10);
  } else {
    const raw = String(d||'').trim();
    const m = raw.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/);
    if (m) od = m[1]+'-'+m[2].padStart(2,'0')+'-'+m[3].padStart(2,'0');
  }
  return {
    order_date:   od,
    member_name:  str(r['이름']),
    ddm_id:       str(r['DDM ID']),
    phone:        str(r['연락처']),
    product_name: str(r['상품명']),
    amount:       toI(r['주문금액']),
    pv:           toI(r['BV']),
    pv2:          toI(r['BV2']),
    order_type:   (() => {
      const t = (str(r['주문종류'] || r['order_type'] || '')).replace(/[\t\s]/g,'');
      if (t === '001' || t === '일반주문') return '1';
      if (t === '002' || t === '유지주문') return '2';
      return t || '1';
    })(),
  };
}

// ── 재구매 여부 판단 ──
// 정규화 후: '2'=재구매, 정규화 전: '002'=재구매
function isRepurchase(s) {
  const t = String(s.order_type || '').replace(/[\t\s]/g,'');
  return t === '2' || t === '002';
}

function showRes(el, msg, ok) {
  el.style.display = 'block';
  el.style.color   = ok ? 'var(--green)' : 'var(--red)';
  el.textContent   = msg;
}

// ── CSV 파싱 ──
function parseCSVLocal(text) {
  text = text.replace(/^\uFEFF/, '');
  const lines = text.split(/\r?\n/);
  if (lines.length < 2) return [];
  const headers = parseCSVLine(lines[0]);
  const result = [];
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const vals = parseCSVLine(line);
    if (vals.every(v => !v)) continue;
    const row = {};
    headers.forEach((h,idx) => { if (h) row[h.trim()] = (vals[idx]||'').trim(); });
    result.push(row);
  }
  return result;
}
function parseCSVLine(line) {
  const result = []; let cur = '', inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') { if (inQ && line[i+1]==='"') { cur += '"'; i++; } else inQ = !inQ; }
    else if (ch === ',' && !inQ) { result.push(cur); cur = ''; }
    else cur += ch;
  }
  result.push(cur);
  return result;
}
